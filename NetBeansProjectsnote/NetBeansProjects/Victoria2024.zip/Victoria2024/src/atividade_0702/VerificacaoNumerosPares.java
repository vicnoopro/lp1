/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade_0702;

import java.util.Scanner;

/**
 *
 * @author Juliana
 */
public class VerificacaoNumerosPares
{
    public static void main(String[] args) 
    {
        int cont = 0;
        while (cont <= 100 )
        {
            if (cont % 2 == 0)
            {
            System.out.println(cont);
            }
            cont=cont+1;
                
        
                
    }
}
}
