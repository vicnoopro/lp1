/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sintaxe;

/**
 *
 * @author 13826640608
 */
public class TiposPrimitivos 
{
    public static void main(String[] args) {
        
        byte idade = -127;
        short nPais = -32767;
        int nAluno = -2147483648;
        long nHabitante = 1000000000000000l; 
        Integer nAluno2;  
        Long x;
        String nome;
        float salario = 1000.35f;
        double totalSalario = 1009000.35;
        
        boolean opcao = true;//false
        char sexo = 'F';
        
    }
    
    
}
