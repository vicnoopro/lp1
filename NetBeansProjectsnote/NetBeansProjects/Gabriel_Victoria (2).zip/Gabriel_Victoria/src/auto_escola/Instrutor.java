/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auto_escola;

/**
 *
 * @author 16189074685
 */
public class Instrutor {
    private String nome_instrutor, tipoCarteira;

    public String getNome_instrutor() {
        return nome_instrutor;
    }

    public void setNome_instrutor(String nome_instrutor) {
        this.nome_instrutor = nome_instrutor;
    }

    public String getTipoCarteira() {
        return tipoCarteira;
    }

    public void setTipoCarteira(String tipoCarteira) {
        this.tipoCarteira = tipoCarteira;
    }
    
    
}
